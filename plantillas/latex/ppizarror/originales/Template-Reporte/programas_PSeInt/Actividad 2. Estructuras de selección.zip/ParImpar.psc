Algoritmo ParImpar
    Escribir "Ingrese un n�mero entero:"
    // Lee el n�mero ingresado por el usuario
    Leer numero
	
    // Verifica si el n�mero es divisible entre 2
    Si numero mod 2 = 0 Entonces
        // Si el residuo es 0, el n�mero es par
        Escribir "El n�mero es par."
    SiNo
        // En caso contrario, el n�mero es impar
        Escribir "El n�mero es impar."
    FinSi
FinAlgoritmo