Algoritmo ReciboNomina
    Escribir "Ingrese el nombre del empleado:"
    // Lee el nombre del empleado
    Leer nombreEmpleado
    Escribir "Ingrese las horas trabajadas:"
    // Lee las horas trabajadas
    Leer horasTrabajadas
    Escribir "Ingrese el departamento (1: Recursos Humanos, 2: Producci�n, 3: Sistemas):"
    // Lee el departamento del empleado
    Leer departamento
    
    // Determina la tarifa por hora normal y por hora extra seg�n el departamento utilizando SWITCH
    Segun departamento Hacer
        1: 
            tarifaNormal <- 23.25 // Recursos Humanos
            tarifaExtra <- 46.50 // Recursos Humanos
        2: 
            tarifaNormal <- 25.20 // Producci�n
            tarifaExtra <- 50.40 // Producci�n
        3: 
            tarifaNormal <- 24.30 // Sistemas
            tarifaExtra <- 48.60 // Sistemas
        De Otro Modo:
            Escribir "Departamento no v�lido. Se asignar�n tarifas por defecto de $23.25 para hora normal y $46.50 para hora extra."
            tarifaNormal <- 23.25 // Tarifa por defecto para hora normal
            tarifaExtra <- 46.50 // Tarifa por defecto para hora extra
    FinSegun
    
    // Calcula el sueldo total considerando horas normales y horas extras
    Si horasTrabajadas <= 40 Entonces
        sueldoTotal <- horasTrabajadas * tarifaNormal
    SiNo
        horasExtras <- horasTrabajadas - 40
        sueldoTotal <- (40 * tarifaNormal) + (horasExtras * tarifaExtra)
    FinSi
    
    // Imprime el recibo de n�mina con el nombre del empleado y su sueldo total
    Escribir "Recibo de N�mina"
    Escribir "Empleado: ", nombreEmpleado
    Escribir "Sueldo Total: $", sueldoTotal
FinAlgoritmo