Algoritmo ReciboLuz
    Escribir "Ingrese el nombre del cliente:"
    // Lee el nombre del cliente
    Leer nombreCliente
    Escribir "Ingrese el consumo en kilowatts:"
    // Lee el consumo en kilowatts
    Leer consumo
    Escribir "Ingrese la zona (1: Monterrey, 2: San Pedro, 3: San Nicol�s, 4: Guadalupe):"
    // Lee la zona del cliente
    Leer zona
    
    // Determina la tarifa por kilowatt seg�n la zona utilizando SWITCH
    Segun zona Hacer
        1: tarifa <- 0.85 // Monterrey
        2: tarifa <- 0.90 // San Pedro
        3: tarifa <- 0.87 // San Nicol�s
        4: tarifa <- 0.82 // Guadalupe
        De Otro Modo:
            Escribir "Zona no v�lida. Se asignar� una tarifa por defecto de $0.85."
            tarifa <- 0.85 // Tarifa por defecto
    FinSegun
    
    // Calcula el pago total multiplicando el consumo por la tarifa
    pagoTotal <- consumo * tarifa
    
    // Imprime el recibo con el nombre del cliente y el pago total
    Escribir "Recibo de Luz"
    Escribir "Cliente: ", nombreCliente
    Escribir "Pago Total: $", pagoTotal
FinAlgoritmo