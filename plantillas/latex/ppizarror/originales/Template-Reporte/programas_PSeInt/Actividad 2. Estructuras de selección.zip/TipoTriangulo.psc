Algoritmo TipoTriangulo
	Escribir 'Ingrese la longitud del primer lado:'
	// Lee la medida del primer lado
	Leer lado1
	Escribir 'Ingrese la longitud del segundo lado:'
	// Lee la medida del segundo lado
	Leer lado2
	Escribir 'Ingrese la longitud del tercer lado:'
	// Lee la medida del tercer lado
	Leer lado3
	// Verifica el tipo de tri�ngulo seg�n las longitudes de los lados
	Si lado1=lado2 Y lado2=lado3 Entonces
		// Si los tres lados son iguales, es equil�tero
		Escribir 'El tri�ngulo es equil�tero.'
	SiNo
		Si lado1=lado2 O lado1=lado3 O lado2=lado3 Entonces
			// Si solo dos lados son iguales, es is�sceles
			Escribir 'El tri�ngulo es is�sceles.'
		SiNo
			// Si todos los lados son diferentes, es escaleno
			Escribir 'El tri�ngulo es escaleno.'
		FinSi
	FinSi
FinAlgoritmo
