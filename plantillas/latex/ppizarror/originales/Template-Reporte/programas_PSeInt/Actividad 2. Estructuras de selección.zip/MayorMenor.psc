Algoritmo MayorMenor
    Escribir "Ingrese el primer n�mero:"
    // Lee el primer n�mero
    Leer num1
    Escribir "Ingrese el segundo n�mero:"
    // Lee el segundo n�mero
    Leer num2
    Escribir "Ingrese el tercer n�mero:"
    // Lee el tercer n�mero
    Leer num3
    
    // Inicializa las variables mayor y menor con el primer n�mero
    mayor <- num1
    menor <- num1
    
    // Compara el segundo n�mero con mayor y menor
    Si num2 > mayor Entonces
        mayor <- num2
    FinSi
    Si num2 < menor Entonces
        menor <- num2
    FinSi
    
    // Compara el tercer n�mero con mayor y menor
    Si num3 > mayor Entonces
        mayor <- num3
    FinSi
    Si num3 < menor Entonces
        menor <- num3
    FinSi
    
    // Imprime los resultados del mayor y menor
    Escribir "El n�mero mayor es: ", mayor
    Escribir "El n�mero menor es: ", menor
FinAlgoritmo