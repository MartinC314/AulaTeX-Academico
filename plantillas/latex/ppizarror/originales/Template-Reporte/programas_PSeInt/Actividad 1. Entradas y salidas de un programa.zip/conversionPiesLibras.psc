Algoritmo conversionPiesLibras
    Escribir "Ingrese la longitud en pies:"
    // Lee la longitud en pies ingresada por el usuario
    Leer longitudPies
    Escribir "Ingrese el peso en libras:"
    // Lee el peso en libras ingresado por el usuario
    Leer pesoLibras
    // Convierte la longitud de pies a metros utilizando la equivalencia 1 pie = 0.3048 metros
    longitudMetros <- longitudPies * 0.3048
    // Convierte el peso de libras a kilogramos utilizando la equivalencia 1 libra = 0.45359 kilogramos
    pesoKilogramos <- pesoLibras * 0.45359
    // Muestra los resultados de la conversi�n en pantalla
    Escribir "La longitud en metros es: ", longitudMetros, " m"
    Escribir "El peso en kilogramos es: ", pesoKilogramos, " kg"
FinAlgoritmo
