Algoritmo SumaDosNumeros
    Escribir "Ingrese el primer n�mero:"
    // Escribe el primer n�mero en pantalla y lo lee desde el teclado
    Leer numero1
    Escribir "Ingrese el segundo n�mero:"
    // Escribe el segundo n�mero en pantalla y lo lee desde el teclado
    Leer numero2
    // Realiza la suma de los dos n�meros y almacena el resultado en la variable suma
    suma <- numero1 + numero2
    // Escribe el resultado de la suma en pantalla
    Escribir "El resultado de la suma es: ", suma
FinAlgoritmo