Algoritmo calculoEnergiaPotencial
    Escribir "Ingrese la masa del objeto (en kg):"
    // Lee la masa del objeto ingresada por el usuario
    Leer masa
    Escribir "Ingrese la altura desde la que cae el objeto (en metros):"
    // Lee la altura desde la que cae el objeto ingresada por el usuario
    Leer altura
    Escribir "Ingrese la gravedad (en m/s^2):"
    // Lee el valor de la gravedad ingresado por el usuario
    Leer gravedad
    // Calcula la energ�a potencial utilizando la f�rmula Epot = mgh
    energiaPotencial <- masa * gravedad * altura
    // Muestra el resultado de la energ�a potencial calculada
    Escribir "La energ�a potencial del objeto es: ", energiaPotencial, " Joules"
FinAlgoritmo
