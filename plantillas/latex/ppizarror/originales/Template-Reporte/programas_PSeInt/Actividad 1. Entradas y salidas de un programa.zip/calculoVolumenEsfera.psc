Algoritmo calculoVolumenEsfera
    Escribir "Ingrese el radio de la esfera (en metros):"
    // Lee el radio de la esfera ingresado por el usuario
    Leer radio
    // Calcula el volumen de la esfera utilizando la f�rmula vol = (4/3) * ? * r^3
    volumen <- (4/3) * 3.14159 * (radio^3)
    // Muestra el resultado del volumen calculado
    Escribir "El volumen de la esfera es: ", volumen, " metros c�bicos"
FinAlgoritmo
