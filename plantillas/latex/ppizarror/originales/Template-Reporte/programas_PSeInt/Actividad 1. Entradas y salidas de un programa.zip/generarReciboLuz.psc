Algoritmo generarReciboLuz
    Escribir "Ingrese el nombre del cliente:"
    // Lee el nombre del cliente ingresado por el usuario
    Leer nombreCliente
    Escribir "Ingrese el consumo en kilowatts:"
    // Lee el consumo en kilowatts ingresado por el usuario
    Leer consumoKilowatts
    Escribir "Ingrese la tarifa del kilowatt:"
    // Lee la tarifa del kilowatt ingresada por el usuario
    Leer tarifaKilowatt
    // Calcula el pago total multiplicando el consumo por la tarifa
    pagoTotal <- consumoKilowatts * tarifaKilowatt
    // Muestra el recibo con el nombre del cliente y el pago total
    Escribir "Recibo de la compa��a de la luz"
    Escribir "Cliente: ", nombreCliente
    Escribir "Pago total: $", pagoTotal
FinAlgoritmo
