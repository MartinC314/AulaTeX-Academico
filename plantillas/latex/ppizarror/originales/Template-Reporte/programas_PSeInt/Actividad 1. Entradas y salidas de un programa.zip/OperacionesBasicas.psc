Algoritmo OperacionesBasicas
    Escribir "Ingrese el primer n�mero:"
    // Lee el primer valor ingresado por el usuario
    Leer numero1
    Escribir "Ingrese el segundo n�mero:"
    // Lee el segundo valor ingresado por el usuario
    Leer numero2
    // Calcula la suma de ambos n�meros
    suma <- numero1 + numero2
    // Calcula la resta del primer n�mero menos el segundo
    resta <- numero1 - numero2
    // Calcula la multiplicaci�n de ambos n�meros
    multiplicacion <- numero1 * numero2
    // Valida que el divisor sea diferente de cero antes de dividir
    Si numero2 <> 0 Entonces
        // Realiza la divisi�n cuando es v�lida
        division <- numero1 / numero2
    Sino
        // Muestra un mensaje de error si el divisor es cero
        Escribir "No se puede dividir por cero"
    FinSi
    // Muestra todos los resultados calculados
    Escribir "Suma: ", suma
    Escribir "Resta: ", resta
    Escribir "Multiplicaci�n: ", multiplicacion
    Escribir "Divisi�n: ", division
FinAlgoritmo
