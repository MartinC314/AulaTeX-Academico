Algoritmo conversionAcresHectareas
    Escribir "Ingrese la extensi�n del terreno en acres:"
    // Lee la extensi�n del terreno en acres ingresada por el usuario
    Leer extensionAcres
    // Convierte la extensi�n de acres a hect�reas utilizando la equivalencia 1 acre = 0.4047 hect�reas
    extensionHectareas <- extensionAcres * 0.4047
    // Muestra el resultado de la conversi�n en pantalla
    Escribir "La extensi�n del terreno en hect�reas es: ", extensionHectareas, " ha"
FinAlgoritmo
